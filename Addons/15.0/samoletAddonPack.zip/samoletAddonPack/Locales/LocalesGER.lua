--windows 1251
--------------------------------------------------------------------------------
-- German
--------------------------------------------------------------------------------

locales["ger"]={}

--------------------------------------------------------------------------------
-- header --
--------------------------------------------------------------------------------
locales["ger"][ "Settings" ] = ToWString("������� | Eksperyment Add-on Pack")
--------------------------------------------------------------------------------
-- buttons --
--------------------------------------------------------------------------------
locales["ger"][ "Apply" ] = ToWString("Apply")
locales["ger"][ "Ok" ] = ToWString("Ok")
locales["ger"][ "Default" ] = ToWString("Default")
locales["ger"][ "Cancel" ] = ToWString("Cancel")
locales["ger"][ "optionDisabled" ] = ToWString("Option Inactive")
locales["ger"][ "Edit" ] = ToWString("Edit")
--------------------------------------------------------------------------------
-- tabs names --
--------------------------------------------------------------------------------
locales["ger"][ "BaseInterface" ] = ToWString("Base Game Interface")
locales["ger"][ "ItemInfo" ] = ToWString("Item Info")
locales["ger"][ "AutoAccept" ] = ToWString("Auto Accept")
locales["ger"][ "Other" ] = ToWString("Other")
--------------------------------------------------------------------------------
-- category names --
--------------------------------------------------------------------------------
--------------------
-- base interface --
--------------------
locales["ger"][ "HideBagFrame" ] = ToWString("Hide Bag Frame")
locales["ger"][ "HideHeader" ] = ToWString("Hide Header")
locales["ger"][ "Plates" ] = ToWString("Plates (avatar)")
locales["ger"][ "ActionBar" ] = ToWString("Action Bar")
locales["ger"][ "ClassSpecific" ] = ToWString("Class Specific")
locales["ger"][ "Misc" ] = ToWString("Misc")
--------------------
-- Item Info --
--------------------
locales["ger"][ "IIStatus" ] = ToWString("Status")
locales["ger"][ "IICategoryTime" ] = ToWString("Time")
locales["ger"][ "IICategoryCompassInsignia" ] = ToWString("Compass and Insignia")
locales["ger"][ "IICategoryGear" ] = ToWString("Equipment")
--------------------
-- Auto Accept --
--------------------
locales["ger"][ "AAStatus" ] = ToWString("Auto Accept Status")
locales["ger"][ "autoAcceptInvite" ] = ToWString("Auto Accept Invite")
locales["ger"][ "autoMatchmaking" ] = ToWString("Auto Matchmaking")
locales["ger"][ "autoLead" ] = ToWString("Auto Pass Lead")
locales["ger"][ "autoInviteCAT" ] = ToWString("Auto Invite")
locales["ger"][ "autoLeaveCAT" ] = ToWString("Auto Leave")
locales["ger"][ "misc" ] = ToWString("Miscellaneous")
--------------------
-- other --
--------------------
locales["ger"][ "OtherCategory1" ] = ToWString("Use Coins Amalgam")
locales["ger"][ "OtherCategory2" ] = ToWString("Pasi Fast Sell")
locales["ger"][ "OtherCategory3" ] = ToWString("Pasi Skip Cutscene")
locales["ger"][ "OtherCategory4" ] = ToWString("Gospodstvo Nekromanta")
locales["ger"][ "OtherCategoryBSS" ] = ToWString("Bag Storage Search")
locales["ger"][ "OtherCategory6" ] = ToWString("Quest Highlight")
locales["ger"][ "OtherCategory7" ] = ToWString("Teleport Search")
locales["ger"][ "OtherCategory8" ] = ToWString("Combats Assist")
locales["ger"][ "OtherCategoryMT" ] = ToWString("Map Transparency")
locales["ger"][ "OtherCategoryMPP" ] = ToWString("Mount Pet Preview")
locales["ger"][ "OtherCategoryBtL" ] = ToWString("Back to Life")
--------------------------------------------------------------------------------
-- option names --
--------------------------------------------------------------------------------
--------------------
-- base interface --
--------------------
locales["ger"][ "HideBagFrameActive" ] = ToWString("Active")
locales["ger"][ "HideBagFrameAlpha" ] = ToWString("Frame Transparency")

locales["ger"][ "HideContextBagHeader" ] = ToWString("Hide Context Bag Header")
locales["ger"][ "HideContextGuildHeader" ] = ToWString("Hide Guild Header")
locales["ger"][ "HideAuctionHeader" ] = ToWString("Hide Auction Header")
locales["ger"][ "HideSocialHeader" ] = ToWString("Hide Social Header")
locales["ger"][ "HideCalendarHeader" ] = ToWString("Hide Calendar Header")
locales["ger"][ "HideContextTalentsHeader" ] = ToWString("Hide Talents Header")

locales["ger"][ "HideContextPlatesHaloSign" ] = ToWString("Hide Plates Halo Sign")
locales["ger"][ "HideContextPlatesUnitQuality" ] = ToWString("Hide Plates Unit Quality")
locales["ger"][ "HideContextPlatesFrameFront" ] = ToWString("Hide Plates Frame Front")
locales["ger"][ "HideContextPlatesMountFrame" ] = ToWString("Hide Plates Mount Frame")
locales["ger"][ "HideContextPlatesLabel" ] = ToWString("Hide Plates Label")

locales["ger"][ "MoveActionBarControls" ] = ToWString("Move Action Bar Controls")
locales["ger"][ "HideActionBarBack" ] = ToWString("Hide Action Bar Back")
locales["ger"][ "HideActionBarBottom" ] = ToWString("Hide Action Bar Bottom")

locales["ger"][ "HidePriestFlare" ] = ToWString("Hide flare on Priest Fanatism")
locales["ger"][ "HideDemoPanel" ] = ToWString("Hide Demonologist Faces Panel")

locales["ger"][ "HideLagMeterFrame" ] = ToWString("Hide Lag Meter Frame")
locales["ger"][ "MoveChatItems" ] = ToWString("Move Chat Items")
locales["ger"][ "MoveRightPinMenuItemFromLeftBottomToRightBottom" ] = ToWString("Put all menu icons on the right")
locales["ger"][ "MoveDownEventIconsOnLeftBottom" ] = ToWString("Move Down Event Icons to the Bottom")
--------------------
-- Item Info --
--------------------
locales["ger"][ "IIStatus1" ] = ToWString("Module Active")

locales["ger"][ "IIOptionTime1" ] = ToWString("Threshold - Expire Soon")
locales["ger"][ "IIOptionTime2" ] = ToWString("Expire Soon - style")
locales["ger"][ "IIOptionTime3" ] = ToWString("Time Label - style")
locales["ger"][ "IIOptionTime4" ] = ToWString("Time low notify on screen")

locales["ger"][ "IIOptionCompassInsignia1" ] = ToWString("Show Compass Level")
locales["ger"][ "IIOptionCompassInsignia2" ] = ToWString("Show Insignia Percentage")
locales["ger"][ "IIOptionCompassInsignia3" ] = ToWString("Compass and Insignia - style")

locales["ger"][ "IIOptionGear1" ] = ToWString("On Equipment in Bag and Bank")
locales["ger"][ "IIOptionGear2" ] = ToWString("On Equipped, Artefacts and Inspection")
locales["ger"][ "IIOptionGear3" ] = ToWString("On Equipment - style")
locales["ger"][ "IIOptionGear4" ] = ToWString("On Equipped Artefacts - style")
locales["ger"][ "IIOptionGear5" ] = ToWString('Show "%" symbol on Equipment')
--------------------
-- Auto Accept --
--------------------
locales["ger"][ "AAStatus1" ] = ToWString("Module Active ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["ger"][ "autoAcceptGroup" ] = ToWString("Accept Group Invitation")
locales["ger"][ "autoAcceptRaid" ] = ToWString("Accept Raid Invitation")
locales["ger"][ "autoAcceptGroupRaidCustomList" ] = ToWString("Custom List ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["ger"][ "matchmakingLeaveOnEnd" ] = ToWString("Leave on Match End")
locales["ger"][ "autoLeaveMatchMakingMapFilterList" ] = ToWString("Map Filter List")
locales["ger"][ "autoAcceptQueue" ] = ToWString("Accept Queue and Other (more in tips)")
locales["ger"][ "queueAsRole" ] = ToWString("Queue as Role")

locales["ger"][ "autoInvite" ] = ToWString("Invite from Whisper")
locales["ger"][ "autoInviteText" ] = ToWString("Invite Command")
locales["ger"][ "autoInviteList" ] = ToWString("Custom List  ") -- keep spaces here, it's an easy fix to problem with same strings for tips
locales["ger"][ "autoInviteGuildChat" ] = ToWString("Invite from Guild Chat")
locales["ger"][ "autoInviteGuildChatText" ] = ToWString("Invite from Guild Chat Command")

locales["ger"][ "autoPassLead" ] = ToWString("Pass Lead")
locales["ger"][ "autoPassLeadText" ] = ToWString("Pass Lead Command")
locales["ger"][ "autoPassLeadCustomList" ] = ToWString("Custom List   ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["ger"][ "autoLeave" ] = ToWString("Leave from Whisper")
locales["ger"][ "autoLeaveText" ] = ToWString("Leave Command")
locales["ger"][ "autoLeaveMapFilterList" ] = ToWString("Map Filter List ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["ger"][ "autoAcceptReadyCheck" ] = ToWString("Accept Ready Check")
locales["ger"][ "autoAcceptMount" ] = ToWString("Accept Lightning Bolt Mount-up")
locales["ger"][ "autoAcceptQuest" ] = ToWString("Accept Shared Quests")
locales["ger"][ "autoAcceptResurrection" ] = ToWString("Accept all Resurrection Requests")
--------------------
-- other --
--------------------
locales["ger"][ "OtherOption1" ] = ToWString("Use Coins Amalgam module")
locales["ger"][ "OtherOption2" ] = ToWString("Pasi Fast Sell module") 
locales["ger"][ "OtherOption3" ] = ToWString("Move Equippable Items")
locales["ger"][ "OtherOption4" ] = ToWString("Pasi Skip Cutscene module - breaks some quests!")
locales["ger"][ "OtherOption5" ] = ToWString("Active as Necromancer")
locales["ger"][ "OtherOptionBSS1" ] = ToWString("Bag Storage Search module")
locales["ger"][ "OtherOptionBSS2" ] = ToWString("Blink duration")
locales["ger"][ "OtherOption8" ] = ToWString("Move Equippable Tradeable Items")
locales["ger"][ "OtherOption9" ] = ToWString("Quest Highlight module") 
locales["ger"][ "OtherOption10" ] = ToWString("Mode") 
locales["ger"][ "OtherOption11" ] = ToWString("Color") 
locales["ger"][ "OtherOption12" ] = ToWString("Color 2") 
locales["ger"][ "OtherOption13" ] = ToWString("Period duration") 
locales["ger"][ "OtherOption14" ] = ToWString("Add additional texts") 
locales["ger"][ "OtherOption15" ] = ToWString("Combats Assist module") 
locales["ger"][ "OtherOption16" ] = ToWString("Amount of Combat Emblems to keep:") 
locales["ger"][ "OtherOptionMT1" ] = ToWString("Background transparency only active while moving") 
locales["ger"][ "OtherOptionMT2" ] = ToWString("Map transparency only active while moving") 
locales["ger"][ "OtherOptionMT3" ] = ToWString("Map transparency") 
locales["ger"][ "OtherOptionMT4" ] = ToWString("Background transparency") 
locales["ger"][ "OtherOptionMT5" ] = ToWString("Map Transparency module") 
locales["ger"][ "OtherOptionMPP" ] = ToWString("Mount Pet Preview module") 
locales["ger"][ "OtherOptionBtL1" ] = ToWString("Back to Life module") 
locales["ger"][ "OtherOptionBtL2" ] = ToWString("Instant resurrect from purgatory") 
locales["ger"][ "OtherOptionBtL3" ] = ToWString("Instant resurrect if out of combat") 
--------------------------------------------------------------------------------
-- others --
--------------------------------------------------------------------------------
locales["ger"]["timerListThresholdLow"] = {"1 hour","2 hours","4 hours","6 hours","12 hours","1 day","2 days","3 days"}
locales["ger"]["pasiFastSellSettingsNamesList"] = {"off", "on except off-hands", "on"}
locales["ger"]["questHighlightModes"] = {"SELECTION", "AMBIENT"}
locales["ger"]["levelLocalized"] = " level: "
locales["ger"]["timeLocalization"] = {["second"] = "s",["minute"] = "m",["hour"] = "h",["day"] = "d"}
locales["ger"]["defaultOnRestart"] = "Will be set to default after game restart or logout to character screen"
--------------------------------------------------------------------------------
-- Auto Accept module
--------------------------------------------------------------------------------
--------------------
-- texts on chat and additional --
--------------------
locales["ger"]["ReadyCheckStarted"]="Ready Check Started"
locales["ger"]["invitationp1"]="You have accepted a "
locales["ger"]["invitationp2"]=" invite from "
locales["ger"]["group"]="group"
locales["ger"]["raid"]="raid"
locales["ger"]["listFill"]='List positions should be separated by ";" for example: name1;name2;name3'
locales["ger"]["IsAFK"]="You are AFK ready check cannot be auto accepted!"
--------------------
-- setting list types --
--------------------
locales["ger"]["acceptTypeLocalized"]={"off", "custom", "friends", "friends and guild", "everyone"}
locales["ger"]["matchmakingLeaveLocalized"]={"off", "on", "exclusion list","inclusion list"}
locales["ger"]["matchmakingRoleQueueLocalized"]={"off", "DD", "TANK", "HEAL"}
--------------------------------------------------------------------------------
-- Bag Storage Search module --
--------------------------------------------------------------------------------
locales["ger"]["search"]="Search"
--------------------------------------------------------------------------------
-- Quest Highlight module --
--------------------------------------------------------------------------------
locales["ger"]["red"]="Red"
locales["ger"]["green"]="Green"
locales["ger"]["blue"]="Blue"
locales["ger"]["alpha"]="Alpha"
--------------------------------------------------------------------------------
-- Combats Assist module --
--------------------------------------------------------------------------------
locales["ger"]["ButtonBuyElixirs"]="Elixirs"
locales["ger"]["ButtonBuyHammers"]="Excellent Tools"
locales["ger"]["ButtonBuyGold"]="Gold"
locales["ger"]["ButtonBuySymbol"]="Symbol of Glory"
locales["ger"]["ButtonBuyNothing"]="Nothing"
locales["ger"]["ButtonSuggestionBlueWins"]="Blue Team Wins"
locales["ger"]["ButtonSuggestionRedWins"]="Red Team Wins"
locales["ger"]["ButtonSuggestionSuggestionOff"]="Suggestion Off"
locales["ger"]["Win"]="Win!"
locales["ger"]["Lose"]="Lose!"
locales["ger"]["BlueWinsExplain"]="Team Blue should win"
locales["ger"]["RedWinsExplain"]="Team Red should win"
--------------------------------------------------------------------------------
-- Mount & Pet Preview module --
--------------------------------------------------------------------------------
locales["ger"]["MountName"]="Mount Preview"
locales["ger"]["PetName"]="Pet Preview"
--------------------------------------------------------------------------------
-- GospodstvoNekromanta module --
--------------------------------------------------------------------------------
locales["ger"]["notify"]="Too close!"
--------------------------------------------------------------------------------
-- tooltips -- 
--------------------------------------------------------------------------------
--------------------
-- BASE INTERFACE --
--------------------
locales["ger"][FromWString(locales["ger"][ "HideBagFrameActive" ])]="<html>Hide bag frame.<br/><tip_red>Option below allows you to change transparency.</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "HideBagFrameAlpha" ])]="<html>Set transparency of bag frame.</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextBagHeader" ])]="<html>Hide Bag Header<br/>(bag moving is handled by pulling header,<br/>and that will be impossible with header hidden).</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextGuildHeader" ])]="<html>Hide Guild Header.</html>"
locales["ger"][FromWString(locales["ger"][ "HideAuctionHeader" ])]="<html>Hide Auction Header.</html>"
locales["ger"][FromWString(locales["ger"][ "HideSocialHeader" ])]="<html>Hide Social Header.</html>"
locales["ger"][FromWString(locales["ger"][ "HideCalendarHeader" ])]="<html>Hide Calendar Header.</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextTalentsHeader" ])]="<html>Hide Talents Header.</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextPlatesHaloSign" ])]="<html>Hide your patron sign.</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextPlatesUnitQuality" ])]="<html>Hide frame of your portrait that<br/>changes depending on your spark level.</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextPlatesFrameFront" ])]="<html>Hide standard frame of your portrait.</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextPlatesMountFrame" ])]="<html>Hide mount icon (leave only health number).</html>"
locales["ger"][FromWString(locales["ger"][ "HideContextPlatesLabel" ])]="<html>Hide your character name and class icon.</html>"
locales["ger"][FromWString(locales["ger"][ "MoveActionBarControls" ])]="<html>Move Action Bar controls to the right.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "HideActionBarBack" ])]="<html>Hides Action Bar backplate.</html>"
locales["ger"][FromWString(locales["ger"][ "HideActionBarBottom" ])]="<html>Hides long bar at the bottom of the screen.</html>"
locales["ger"][FromWString(locales["ger"][ "HidePriestFlare"])]="<html>Removes flashing flares on Fanatism.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "HideDemoPanel" ])]="<html>Hides bulky decorations on demonologist faces.</html>"
locales["ger"][FromWString(locales["ger"][ "HideLagMeterFrame" ])]="<html>Hide unnecessary frame on top right.</html>"
locales["ger"][FromWString(locales["ger"][ "MoveChatItems" ])]="<html>Removes frame that emotion option sit on<br/>and allow chat to move closer to the edge of screen.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "MoveRightPinMenuItemFromLeftBottomToRightBottom" ])]="<html>Move all settings to same place on the right.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "MoveDownEventIconsOnLeftBottom" ])]="<html>Moves event icons on left bottom further down,<br/>allows you to move chat a bit lower.<br/><tip_red>Will be set to default only after game restart!   </tip_red></html>"
--------------------
-- ITEM INFO --
--------------------
locales["ger"][FromWString(locales["ger"][ "IIStatus1" ])]="<html>Is module active?<br/><tip_blue>Adds labels with additional information to<br/>bag, bank, character and inspect view.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionTime1" ])]="<html>Time threshold at which item will change color.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionTime2" ])]="<html>Expire soon labels - style.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionTime3" ])]="<html>Times labels - style.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionCompassInsignia1" ])]="<html>Show compass level labels.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionCompassInsignia2" ])]="<html>Show insignia percentage labels.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionCompassInsignia3" ])]="<html>Compass and insignia labels - style.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionGear1" ])]="<html>Show labels on equipment located in bag and bank.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionGear2" ])]="<html>Show labels on equipped items, artefacts<br/>and while inspecting others.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionGear3" ])]="<html>Equipment in bag, bank, equipped<br/> and inspected labels - style.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionGear4" ])]="<html>Equipped artefacts labels - style.</html>"
locales["ger"][FromWString(locales["ger"][ "IIOptionGear5" ])]="<html>Use if you want to additionally see percentage symbol<br/>along with a number.</html>"
--------------------
-- AUTO ACCEPT --
--------------------
locales["ger"][FromWString(locales["ger"][ "AAStatus1" ])]="<html>Is module active?<br/><tip_blue>Automates group invites, content sign,<br/>functions activated through chat etc.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptGroup" ])]="<html><tip_blue>From who do you want to auto accept group invites?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to accept group invites from.<br/><tip_red>Note that list is shared with raid invites if you have also set that option to 'custom'.</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptRaid" ])]="<html><tip_blue>From who do you want to auto accept raid invites?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to accept raid invites from.<br/><tip_red>Note that list is shared with group invites if you have also set that option to 'custom'.</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptGroupRaidCustomList" ])]="<html><tip_red>In use only if you have set at least one of two above options to 'custom'.</tip_red><br/>Your list of nicknames that will be accepted when receiving invites.<br/><tip_blue>List positions should be separated with semicolon (';'),<br/>for example: nickname1;nickname2;nickname3.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "matchmakingLeaveOnEnd" ])]="<html>Leave after the end of Matchmaking content<br/>It consists of most of PvP maps and <tip_red>after plundering maze, note that there is a timer of 30 seconds<br/>and if you enter maze again before it runs out or click it yourself it will make you leave and lose the run.</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "autoLeaveMatchMakingMapFilterList" ])]="<html><tip_red>In use only if you have set above option to either 'inclusion list' or 'exclusion list'.</tip_red><br/>Your list of maps that will be compared with your current location when trying to leave finished matchmaking.<br/>Exlusive means that if the map name is on the list you stay, if not then you leave.<br/>Inclusive is the other way. If map name is on the list you leave and if not then you stay.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: Private Allod;Arena of Death;Witch Hollow.</tip_blue><br/><tip_blue>You can check map names with command: /aa map.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptQueue" ])]="<html>Auto accept questions asked by game like:<br/>Do you want to join 3v3?<br/>Do you want to join mazes?<br/>Do you want to be my Irene duel partner?<br/>There isn't many options for exclusion as of now, more might be added later.<br/>You can find these options in <tip_blue>Miscellaneous section</tip_blue>.</html>"
locales["ger"][FromWString(locales["ger"][ "queueAsRole" ])]="<html>For some type of content there is a need to choose your role:<br/>Damage Dealer, Tank, Healer.<br/>Using game interface you are limited to choice of roles you have aspect for.<br/>Fear not! With this option you can choose any role.<br/>Want to sign as a healer but you are scout? Why not!<br/>If you set this option to 'off' add-on will do nothing when role choice happens.</html>"
locales["ger"][FromWString(locales["ger"][ "autoInvite" ])]="<html><tip_blue>Who will you invite after they send you a whisper with chosen command?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to invite from whisper command.</html>"
locales["ger"][FromWString(locales["ger"][ "autoInviteText" ])]="<html>Select a phrase which will trigger you to invite a person after receiving a whisper.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: +;++;invite.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoInviteList" ])]="<html><tip_red>In use only if you have 'invite from whisper' option set to 'custom'.</tip_red><br/>Your list of nicknames that you will invite<br/>after wshipering you a correct command you have set in the option above.<br/><tip_blue>List positions should be separated with semicolon (';'), for example:<br/>nickname1;nickname2;nickname3.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoInviteGuildChat" ])]="<html>Invite people that use command (you can set it below) on guild chat.</html>"
locales["ger"][FromWString(locales["ger"][ "autoInviteGuildChatText" ])]="<html><tip_red>In use only if you have selected above option.</tip_red><br/>Select a phrase which will trigger you to invite a person after them writing on guild chat.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: ++;raid;invite.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoPassLead" ])]="<html><tip_blue>Who will be able to take leadership from you with a chosen whisper command?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want allow to take leadership from you.</html>"
locales["ger"][FromWString(locales["ger"][ "autoPassLeadText" ])]="<html>Select a phrase which will trigger you to pass leadership<br/>to a person after receiving a whisper.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: !;!!;lead.   </tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoPassLeadCustomList" ])]="<html><tip_red>In use only if you have 'Pass Lead' option set to 'custom'.</tip_red><br/>Your list of nicknames that you will pass leadership to,<br/>after wshipering you with a correct command<br/>you have set in the option above.<br/><tip_blue>List positions should be separated with semicolon (';'), for example:<br/>nickname1;nickname2;nickname3.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoLeave" ])]="<html>Leave group or raid after receiving whisper with correct command.</html>"
locales["ger"][FromWString(locales["ger"][ "autoLeaveText" ])]="<html>Select a phrase which will trigger you to leave<br/>group or raid after receiving a whisper.<br/><tip_blue>List positions should be separated with semicolon (';'), for example:<br/>-;--;leave.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoLeaveMapFilterList" ])]="<html><tip_red>In use only if you have set 'Leave from Whisper' option to either 'inclusion list' or 'exclusion list'.</tip_red><br/>Your list of maps that will be compared with your current location<br/>when someone triggers you to leave a group or raid by whispering a leave command.<br/>Exlusive means that if the map name is on the list you stay, if not then you leave.<br/>Inclusive is the other way. If map name is on the list you leave and if not then you stay.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: The Empire;Irene;Kingdom of Elements.</tip_blue><br/><tip_blue>You can check map names with command: /aa map.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptReadyCheck" ])]="<html>Auto accept ready checks.</html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptMount" ])]="<html>Auto accept lightning bolt mount-up invite.</html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptQuest" ])]="<html>Auto accept shared quests.</html>"
locales["ger"][FromWString(locales["ger"][ "autoAcceptResurrection" ])]="<html>Auto accept resurrection offers.</html>"
--------------------
-- OTHER --
--------------------
locales["ger"][FromWString(locales["ger"][ "OtherOption1" ])]="<html><tip_blue>Automatically combines:<br/>amalgam, realgar, battlegrounds coins, and other items.</tip_blue><br/>It will only work when there has been a change in your bag<br/>and will go through all possible items.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption2" ])]="<html><tip_blue>Addon simplifies selling junk items with option to add any item of your choice.</tip_blue><br/>Sell item and addon will move next into same slot for you.<br/>Config additional items in NpcableStuff.lua</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption3" ])]="<html>Move equippable items<br/>(only items that are equal or weaker than equipped - addon checks item level)</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption8" ])]="<html>Move items that can be equipped and are tradeable</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption4" ])]="<html><tip_blue>Automatically skips skippable cutscenes</tip_blue><br/><tip_red>It breaks some quests, most notably in Dane!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption5" ])]="<html>Necromancer Supremacy helper.<br/><tip_blue>Highlights anyone from group who is within 6 m and puts text on screen.</tip_blue><br/><tip_red>Works only on Necromancer!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionBSS1" ])]="<html><tip_blue>Fast and easy search in bag and bank.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionBSS2" ])]="<html>Found items blink after pressing 'Enter'.<br/>You can set blink duration here.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption9" ])]="<html><tip_blue>Highlights quest related objects and units</tip_blue> - it does not highlight everything like ingame highlight does,<br/>which to myself was very annoying and this add-on is a result.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption10" ])]="<html>Selection - color over whole object, Ambient - color1 changing into color2<br/>and back into color1 within a set period.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption11" ])]="<html>Color 1</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption12" ])]="<html>Color 2<br/>(works only with AMBIENT mode)</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption13" ])]="<html>period during which Color 1 changes into Color 2<br/>(works only with AMBIENT mode)</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption14" ])]="<html>Should additional texts in teleport window be shown?<br/>For example 'Dane. Bee Ravine' will have added 'Fractal' raid name or any other text you have set.<br/>Check add-on page on alloder.pro for in-depth tutorial.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption15" ])]="<html><tip_blue>Automation of boring tasks that allow you to focus on battles in 3v3 and 6v6 formats.</tip_blue><br/><tip_red>Even if it's active here you have to right-click on the CA icon to activate the add-on itself.<br/>This option affects only visibility of CA button!</tip_red><br/>When activated add-on automatically accepts queue and leaves after the end of the battle.<br/>Allows automatic purchase of: Essence, Tools, Symbols of Glory and Gold.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOption16" ])]="<html>How much Combat Emlems should be kept?<br/>Only the value above set one will be spent for buying.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionMT1" ])]="<html>should background transparency be only active while moving,<br/>if set to off it will be active all the time and won't affect performance.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionMT2" ])]="<html>should map transparency be only active while moving,<br/>if set to off it will be active all the time and won't affect performance.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionMT3" ])]="<html>map transparency<br/>can be set from 0 to 1 with 0 being fully transparent and 1 being fully visible.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionMT4" ])]="<html>background transparency, can be set from 0 to 1 with 0 being fully transparent and 1 being fully visible.</html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionMT5" ])]="<html><tip_blue>Makes map transparent on movement or at all times.</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionMPP" ])]="<html><tip_blue>Allows to preview: mount, shell skins and pets<br/>by left clicking while holding alt on skin item linked to chat (same way as costumes can be previewed).</tip_blue><br/><tip_red>Note that some mount items don't contain any info about skin and can't be viewed in the addon.<br/>Developers take their time fixing it...</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionBtL1" ])]="<html><tip_blue>Speed up your resurrection!<br/>No more walking to the goblin!<br/>Just shout and throw mirra at him!</tip_blue></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionBtL2" ])]="<html>Instantly leave purgatory after accepting respawn.<br/><tip_red>Remember to keep a stockpile of mirra!</tip_red></html>"
locales["ger"][FromWString(locales["ger"][ "OtherOptionBtL3" ])]="<html>Instantly resurrect if you are out of combat when dying.<br/><tip_red>It will only work at the time of death.<br/>If combat ends later you have to accept yourself!</tip_red></html>"

-- to add new tooltip (development only)
--locales["ger"][FromWString(locales["ger"][ "localeName" ])]="<html><tip_red>tip_red</tip_red><br/><tip_blue>tip_blue</tip_blue><br/>long tip text|long tip text</html>"