--windows 1251
--------------------------------------------------------------------------------
-- English
--------------------------------------------------------------------------------

locales["eng_eu"]={}

--------------------------------------------------------------------------------
-- header --
--------------------------------------------------------------------------------
locales["eng_eu"][ "Settings" ] = ToWString("������� | Eksperyment Add-on Pack")
--------------------------------------------------------------------------------
-- buttons --
--------------------------------------------------------------------------------
locales["eng_eu"][ "Apply" ] = ToWString("Apply")
locales["eng_eu"][ "Ok" ] = ToWString("Ok")
locales["eng_eu"][ "Default" ] = ToWString("Default")
locales["eng_eu"][ "Cancel" ] = ToWString("Cancel")
locales["eng_eu"][ "optionDisabled" ] = ToWString("Option Inactive")
locales["eng_eu"][ "Edit" ] = ToWString("Edit")
--------------------------------------------------------------------------------
-- tabs names --
--------------------------------------------------------------------------------
locales["eng_eu"][ "BaseInterface" ] = ToWString("Base Game Interface")
locales["eng_eu"][ "ItemInfo" ] = ToWString("Item Info")
locales["eng_eu"][ "AutoAccept" ] = ToWString("Auto Accept")
locales["eng_eu"][ "Other" ] = ToWString("Other")
--------------------------------------------------------------------------------
-- category names --
--------------------------------------------------------------------------------
--------------------
-- base interface --
--------------------
locales["eng_eu"][ "HideBagFrame" ] = ToWString("Hide Bag Frame")
locales["eng_eu"][ "HideHeader" ] = ToWString("Hide Header")
locales["eng_eu"][ "Plates" ] = ToWString("Plates (avatar)")
locales["eng_eu"][ "ActionBar" ] = ToWString("Action Bar")
locales["eng_eu"][ "ClassSpecific" ] = ToWString("Class Specific")
locales["eng_eu"][ "Misc" ] = ToWString("Misc")
--------------------
-- Item Info --
--------------------
locales["eng_eu"][ "IIStatus" ] = ToWString("Status")
locales["eng_eu"][ "IICategoryTime" ] = ToWString("Time")
locales["eng_eu"][ "IICategoryCompassInsignia" ] = ToWString("Compass and Insignia")
locales["eng_eu"][ "IICategoryGear" ] = ToWString("Equipment")
--------------------
-- Auto Accept --
--------------------
locales["eng_eu"][ "AAStatus" ] = ToWString("Auto Accept Status")
locales["eng_eu"][ "autoAcceptInvite" ] = ToWString("Auto Accept Invite")
locales["eng_eu"][ "autoMatchmaking" ] = ToWString("Auto Matchmaking")
locales["eng_eu"][ "autoLead" ] = ToWString("Auto Pass Lead")
locales["eng_eu"][ "autoInviteCAT" ] = ToWString("Auto Invite")
locales["eng_eu"][ "autoLeaveCAT" ] = ToWString("Auto Leave")
locales["eng_eu"][ "misc" ] = ToWString("Miscellaneous")
--------------------
-- other --
--------------------
locales["eng_eu"][ "OtherCategory1" ] = ToWString("Use Coins Amalgam")
locales["eng_eu"][ "OtherCategory2" ] = ToWString("Pasi Fast Sell")
locales["eng_eu"][ "OtherCategory3" ] = ToWString("Pasi Skip Cutscene")
locales["eng_eu"][ "OtherCategory4" ] = ToWString("Gospodstvo Nekromanta")
locales["eng_eu"][ "OtherCategoryBSS" ] = ToWString("Bag Storage Search")
locales["eng_eu"][ "OtherCategory6" ] = ToWString("Quest Highlight")
locales["eng_eu"][ "OtherCategory7" ] = ToWString("Teleport Search")
locales["eng_eu"][ "OtherCategory8" ] = ToWString("Combats Assist")
locales["eng_eu"][ "OtherCategoryMT" ] = ToWString("Map Transparency")
locales["eng_eu"][ "OtherCategoryMPP" ] = ToWString("Mount Pet Preview")
locales["eng_eu"][ "OtherCategoryBtL" ] = ToWString("Back to Life")
--------------------------------------------------------------------------------
-- option names --
--------------------------------------------------------------------------------
--------------------
-- base interface --
--------------------
locales["eng_eu"][ "HideBagFrameActive" ] = ToWString("Active")
locales["eng_eu"][ "HideBagFrameAlpha" ] = ToWString("Frame Transparency")

locales["eng_eu"][ "HideContextBagHeader" ] = ToWString("Hide Context Bag Header")
locales["eng_eu"][ "HideContextGuildHeader" ] = ToWString("Hide Guild Header")
locales["eng_eu"][ "HideAuctionHeader" ] = ToWString("Hide Auction Header")
locales["eng_eu"][ "HideSocialHeader" ] = ToWString("Hide Social Header")
locales["eng_eu"][ "HideCalendarHeader" ] = ToWString("Hide Calendar Header")
locales["eng_eu"][ "HideContextTalentsHeader" ] = ToWString("Hide Talents Header")

locales["eng_eu"][ "HideContextPlatesHaloSign" ] = ToWString("Hide Plates Halo Sign")
locales["eng_eu"][ "HideContextPlatesUnitQuality" ] = ToWString("Hide Plates Unit Quality")
locales["eng_eu"][ "HideContextPlatesFrameFront" ] = ToWString("Hide Plates Frame Front")
locales["eng_eu"][ "HideContextPlatesMountFrame" ] = ToWString("Hide Plates Mount Frame")
locales["eng_eu"][ "HideContextPlatesLabel" ] = ToWString("Hide Plates Label")

locales["eng_eu"][ "MoveActionBarControls" ] = ToWString("Move Action Bar Controls")
locales["eng_eu"][ "HideActionBarBack" ] = ToWString("Hide Action Bar Back")
locales["eng_eu"][ "HideActionBarBottom" ] = ToWString("Hide Action Bar Bottom")

locales["eng_eu"][ "HidePriestFlare" ] = ToWString("Hide flare on Priest Fanatism")
locales["eng_eu"][ "HideDemoPanel" ] = ToWString("Hide Demonologist Faces Panel")

locales["eng_eu"][ "HideLagMeterFrame" ] = ToWString("Hide Lag Meter Frame")
locales["eng_eu"][ "MoveChatItems" ] = ToWString("Move Chat Items")
locales["eng_eu"][ "MoveRightPinMenuItemFromLeftBottomToRightBottom" ] = ToWString("Put all menu icons on the right")
locales["eng_eu"][ "MoveDownEventIconsOnLeftBottom" ] = ToWString("Move Down Event Icons to the Bottom")
--------------------
-- Item Info --
--------------------
locales["eng_eu"][ "IIStatus1" ] = ToWString("Module Active")

locales["eng_eu"][ "IIOptionTime1" ] = ToWString("Threshold - Expire Soon")
locales["eng_eu"][ "IIOptionTime2" ] = ToWString("Expire Soon - style")
locales["eng_eu"][ "IIOptionTime3" ] = ToWString("Time Label - style")
locales["eng_eu"][ "IIOptionTime4" ] = ToWString("Time low notify on screen")

locales["eng_eu"][ "IIOptionCompassInsignia1" ] = ToWString("Show Compass Level")
locales["eng_eu"][ "IIOptionCompassInsignia2" ] = ToWString("Show Insignia Percentage")
locales["eng_eu"][ "IIOptionCompassInsignia3" ] = ToWString("Compass and Insignia - style")

locales["eng_eu"][ "IIOptionGear1" ] = ToWString("On Equipment in Bag and Bank")
locales["eng_eu"][ "IIOptionGear2" ] = ToWString("On Equipped, Artefacts and Inspection")
locales["eng_eu"][ "IIOptionGear3" ] = ToWString("On Equipment - style")
locales["eng_eu"][ "IIOptionGear4" ] = ToWString("On Equipped Artefacts - style")
locales["eng_eu"][ "IIOptionGear5" ] = ToWString('Show "%" symbol on Equipment')
--------------------
-- Auto Accept --
--------------------
locales["eng_eu"][ "AAStatus1" ] = ToWString("Module Active ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["eng_eu"][ "autoAcceptGroup" ] = ToWString("Accept Group Invitation")
locales["eng_eu"][ "autoAcceptRaid" ] = ToWString("Accept Raid Invitation")
locales["eng_eu"][ "autoAcceptGroupRaidCustomList" ] = ToWString("Custom List ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["eng_eu"][ "matchmakingLeaveOnEnd" ] = ToWString("Leave on Match End")
locales["eng_eu"][ "autoLeaveMatchMakingMapFilterList" ] = ToWString("Map Filter List")
locales["eng_eu"][ "autoAcceptQueue" ] = ToWString("Accept Queue and Other (more in tips)")
locales["eng_eu"][ "queueAsRole" ] = ToWString("Queue as Role")

locales["eng_eu"][ "autoInvite" ] = ToWString("Invite from Whisper")
locales["eng_eu"][ "autoInviteText" ] = ToWString("Invite Command")
locales["eng_eu"][ "autoInviteList" ] = ToWString("Custom List  ") -- keep spaces here, it's an easy fix to problem with same strings for tips
locales["eng_eu"][ "autoInviteGuildChat" ] = ToWString("Invite from Guild Chat")
locales["eng_eu"][ "autoInviteGuildChatText" ] = ToWString("Invite from Guild Chat Command")

locales["eng_eu"][ "autoPassLead" ] = ToWString("Pass Lead")
locales["eng_eu"][ "autoPassLeadText" ] = ToWString("Pass Lead Command")
locales["eng_eu"][ "autoPassLeadCustomList" ] = ToWString("Custom List   ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["eng_eu"][ "autoLeave" ] = ToWString("Leave from Whisper")
locales["eng_eu"][ "autoLeaveText" ] = ToWString("Leave Command")
locales["eng_eu"][ "autoLeaveMapFilterList" ] = ToWString("Map Filter List ") -- keep spaces here, it's an easy fix to problem with same strings for tips

locales["eng_eu"][ "autoAcceptReadyCheck" ] = ToWString("Accept Ready Check")
locales["eng_eu"][ "autoAcceptMount" ] = ToWString("Accept Lightning Bolt Mount-up")
locales["eng_eu"][ "autoAcceptQuest" ] = ToWString("Accept Shared Quests")
locales["eng_eu"][ "autoAcceptResurrection" ] = ToWString("Accept all Resurrection Requests")
--------------------
-- other --
--------------------
locales["eng_eu"][ "OtherOption1" ] = ToWString("Use Coins Amalgam module")
locales["eng_eu"][ "OtherOption2" ] = ToWString("Pasi Fast Sell module") 
locales["eng_eu"][ "OtherOption3" ] = ToWString("Move Equippable Items")
locales["eng_eu"][ "OtherOption4" ] = ToWString("Pasi Skip Cutscene module - breaks some quests!")
locales["eng_eu"][ "OtherOption5" ] = ToWString("Active as Necromancer")
locales["eng_eu"][ "OtherOptionBSS1" ] = ToWString("Bag Storage Search module")
locales["eng_eu"][ "OtherOptionBSS2" ] = ToWString("Blink duration")
locales["eng_eu"][ "OtherOption8" ] = ToWString("Move Equippable Tradeable Items")
locales["eng_eu"][ "OtherOption9" ] = ToWString("Quest Highlight module") 
locales["eng_eu"][ "OtherOption10" ] = ToWString("Mode") 
locales["eng_eu"][ "OtherOption11" ] = ToWString("Color") 
locales["eng_eu"][ "OtherOption12" ] = ToWString("Color 2") 
locales["eng_eu"][ "OtherOption13" ] = ToWString("Period duration") 
locales["eng_eu"][ "OtherOption14" ] = ToWString("Add additional texts") 
locales["eng_eu"][ "OtherOption15" ] = ToWString("Combats Assist module") 
locales["eng_eu"][ "OtherOption16" ] = ToWString("Amount of Combat Emblems to keep:") 
locales["eng_eu"][ "OtherOptionMT1" ] = ToWString("Background transparency only active while moving") 
locales["eng_eu"][ "OtherOptionMT2" ] = ToWString("Map transparency only active while moving") 
locales["eng_eu"][ "OtherOptionMT3" ] = ToWString("Map transparency") 
locales["eng_eu"][ "OtherOptionMT4" ] = ToWString("Background transparency") 
locales["eng_eu"][ "OtherOptionMT5" ] = ToWString("Map Transparency module") 
locales["eng_eu"][ "OtherOptionMPP" ] = ToWString("Mount Pet Preview module") 
locales["eng_eu"][ "OtherOptionBtL1" ] = ToWString("Back to Life module") 
locales["eng_eu"][ "OtherOptionBtL2" ] = ToWString("Instant resurrect from purgatory") 
locales["eng_eu"][ "OtherOptionBtL3" ] = ToWString("Instant resurrect if out of combat") 
--------------------------------------------------------------------------------
-- others --
--------------------------------------------------------------------------------
locales["eng_eu"]["timerListThresholdLow"] = {"1 hour","2 hours","4 hours","6 hours","12 hours","1 day","2 days","3 days"}
locales["eng_eu"]["pasiFastSellSettingsNamesList"] = {"off", "on except off-hands", "on"}
locales["eng_eu"]["questHighlightModes"] = {"SELECTION", "AMBIENT"}
locales["eng_eu"]["levelLocalized"] = " level: "
locales["eng_eu"]["timeLocalization"] = {["second"] = "s",["minute"] = "m",["hour"] = "h",["day"] = "d"}
locales["eng_eu"]["defaultOnRestart"] = "Will be set to default after game restart or logout to character screen"
--------------------------------------------------------------------------------
-- Auto Accept module
--------------------------------------------------------------------------------
--------------------
-- texts on chat and additional --
--------------------
locales["eng_eu"]["ReadyCheckStarted"]="Ready Check Started"
locales["eng_eu"]["invitationp1"]="You have accepted a "
locales["eng_eu"]["invitationp2"]=" invite from "
locales["eng_eu"]["group"]="group"
locales["eng_eu"]["raid"]="raid"
locales["eng_eu"]["listFill"]='List positions should be separated by ";" for example: name1;name2;name3'
locales["eng_eu"]["IsAFK"]="You are AFK ready check cannot be auto accepted!"
--------------------
-- setting list types --
--------------------
locales["eng_eu"]["acceptTypeLocalized"]={"off", "custom", "friends", "friends and guild", "everyone"}
locales["eng_eu"]["matchmakingLeaveLocalized"]={"off", "on", "exclusion list","inclusion list"}
locales["eng_eu"]["matchmakingRoleQueueLocalized"]={"off", "DD", "TANK", "HEAL"}
--------------------------------------------------------------------------------
-- Bag Storage Search module --
--------------------------------------------------------------------------------
locales["eng_eu"]["search"]="Search"
--------------------------------------------------------------------------------
-- Quest Highlight module --
--------------------------------------------------------------------------------
locales["eng_eu"]["red"]="Red"
locales["eng_eu"]["green"]="Green"
locales["eng_eu"]["blue"]="Blue"
locales["eng_eu"]["alpha"]="Alpha"
--------------------------------------------------------------------------------
-- Combats Assist module --
--------------------------------------------------------------------------------
locales["eng_eu"]["ButtonBuyElixirs"]="Elixirs"
locales["eng_eu"]["ButtonBuyHammers"]="Excellent Tools"
locales["eng_eu"]["ButtonBuyGold"]="Gold"
locales["eng_eu"]["ButtonBuySymbol"]="Symbol of Glory"
locales["eng_eu"]["ButtonBuyNothing"]="Nothing"
locales["eng_eu"]["ButtonSuggestionBlueWins"]="Blue Team Wins"
locales["eng_eu"]["ButtonSuggestionRedWins"]="Red Team Wins"
locales["eng_eu"]["ButtonSuggestionSuggestionOff"]="Suggestion Off"
locales["eng_eu"]["Win"]="Win!"
locales["eng_eu"]["Lose"]="Lose!"
locales["eng_eu"]["BlueWinsExplain"]="Team Blue should win"
locales["eng_eu"]["RedWinsExplain"]="Team Red should win"
--------------------------------------------------------------------------------
-- Mount & Pet Preview module --
--------------------------------------------------------------------------------
locales["eng_eu"]["MountName"]="Mount Preview"
locales["eng_eu"]["PetName"]="Pet Preview"
--------------------------------------------------------------------------------
-- GospodstvoNekromanta module --
--------------------------------------------------------------------------------
locales["eng_eu"]["notify"]="Too close!"
--------------------------------------------------------------------------------
-- tooltips -- 
--------------------------------------------------------------------------------
--------------------
-- BASE INTERFACE --
--------------------
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideBagFrameActive" ])]="<html>Hide bag frame.<br/><tip_red>Option below allows you to change transparency.</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideBagFrameAlpha" ])]="<html>Set transparency of bag frame.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextBagHeader" ])]="<html>Hide Bag Header<br/>(bag moving is handled by pulling header,<br/>and that will be impossible with header hidden).</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextGuildHeader" ])]="<html>Hide Guild Header.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideAuctionHeader" ])]="<html>Hide Auction Header.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideSocialHeader" ])]="<html>Hide Social Header.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideCalendarHeader" ])]="<html>Hide Calendar Header.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextTalentsHeader" ])]="<html>Hide Talents Header.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextPlatesHaloSign" ])]="<html>Hide your patron sign.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextPlatesUnitQuality" ])]="<html>Hide frame of your portrait that<br/>changes depending on your spark level.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextPlatesFrameFront" ])]="<html>Hide standard frame of your portrait.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextPlatesMountFrame" ])]="<html>Hide mount icon (leave only health number).</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideContextPlatesLabel" ])]="<html>Hide your character name and class icon.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "MoveActionBarControls" ])]="<html>Move Action Bar controls to the right.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideActionBarBack" ])]="<html>Hides Action Bar backplate.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideActionBarBottom" ])]="<html>Hides long bar at the bottom of the screen.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HidePriestFlare"])]="<html>Removes flashing flares on Fanatism.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideDemoPanel" ])]="<html>Hides bulky decorations on demonologist faces.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "HideLagMeterFrame" ])]="<html>Hide unnecessary frame on top right.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "MoveChatItems" ])]="<html>Removes frame that emotion option sit on<br/>and allow chat to move closer to the edge of screen.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "MoveRightPinMenuItemFromLeftBottomToRightBottom" ])]="<html>Move all settings to same place on the right.<br/><tip_red>Will be set to default only after game restart!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "MoveDownEventIconsOnLeftBottom" ])]="<html>Moves event icons on left bottom further down,<br/>allows you to move chat a bit lower.<br/><tip_red>Will be set to default only after game restart!   </tip_red></html>"
--------------------
-- ITEM INFO --
--------------------
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIStatus1" ])]="<html>Is module active?<br/><tip_blue>Adds labels with additional information to<br/>bag, bank, character and inspect view.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionTime1" ])]="<html>Time threshold at which item will change color.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionTime2" ])]="<html>Expire soon labels - style.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionTime3" ])]="<html>Times labels - style.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionCompassInsignia1" ])]="<html>Show compass level labels.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionCompassInsignia2" ])]="<html>Show insignia percentage labels.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionCompassInsignia3" ])]="<html>Compass and insignia labels - style.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionGear1" ])]="<html>Show labels on equipment located in bag and bank.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionGear2" ])]="<html>Show labels on equipped items, artefacts<br/>and while inspecting others.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionGear3" ])]="<html>Equipment in bag, bank, equipped<br/> and inspected labels - style.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionGear4" ])]="<html>Equipped artefacts labels - style.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "IIOptionGear5" ])]="<html>Use if you want to additionally see percentage symbol<br/>along with a number.</html>"
--------------------
-- AUTO ACCEPT --
--------------------
locales["eng_eu"][FromWString(locales["eng_eu"][ "AAStatus1" ])]="<html>Is module active?<br/><tip_blue>Automates group invites, content sign,<br/>functions activated through chat etc.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptGroup" ])]="<html><tip_blue>From who do you want to auto accept group invites?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to accept group invites from.<br/><tip_red>Note that list is shared with raid invites if you have also set that option to 'custom'.</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptRaid" ])]="<html><tip_blue>From who do you want to auto accept raid invites?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to accept raid invites from.<br/><tip_red>Note that list is shared with group invites if you have also set that option to 'custom'.</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptGroupRaidCustomList" ])]="<html><tip_red>In use only if you have set at least one of two above options to 'custom'.</tip_red><br/>Your list of nicknames that will be accepted when receiving invites.<br/><tip_blue>List positions should be separated with semicolon (';'),<br/>for example: nickname1;nickname2;nickname3.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "matchmakingLeaveOnEnd" ])]="<html>Leave after the end of Matchmaking content<br/>It consists of most of PvP maps and <tip_red>after plundering maze, note that there is a timer of 30 seconds<br/>and if you enter maze again before it runs out or click it yourself it will make you leave and lose the run.</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoLeaveMatchMakingMapFilterList" ])]="<html><tip_red>In use only if you have set above option to either 'inclusion list' or 'exclusion list'.</tip_red><br/>Your list of maps that will be compared with your current location when trying to leave finished matchmaking.<br/>Exlusive means that if the map name is on the list you stay, if not then you leave.<br/>Inclusive is the other way. If map name is on the list you leave and if not then you stay.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: Private Allod;Arena of Death;Witch Hollow.</tip_blue><br/><tip_blue>You can check map names with command: /aa map.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptQueue" ])]="<html>Auto accept questions asked by game like:<br/>Do you want to join 3v3?<br/>Do you want to join mazes?<br/>Do you want to be my Irene duel partner?<br/>There isn't many options for exclusion as of now, more might be added later.<br/>You can find these options in <tip_blue>Miscellaneous section</tip_blue>.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "queueAsRole" ])]="<html>For some type of content there is a need to choose your role:<br/>Damage Dealer, Tank, Healer.<br/>Using game interface you are limited to choice of roles you have aspect for.<br/>Fear not! With this option you can choose any role.<br/>Want to sign as a healer but you are scout? Why not!<br/>If you set this option to 'off' add-on will do nothing when role choice happens.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoInvite" ])]="<html><tip_blue>Who will you invite after they send you a whisper with chosen command?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to invite from whisper command.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoInviteText" ])]="<html>Select a phrase which will trigger you to invite a person after receiving a whisper.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: +;++;invite.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoInviteList" ])]="<html><tip_red>In use only if you have 'invite from whisper' option set to 'custom'.</tip_red><br/>Your list of nicknames that you will invite<br/>after whispering you a correct command you have set in the option above.<br/><tip_blue>List positions should be separated with semicolon (';'), for example:<br/>nickname1;nickname2;nickname3.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoInviteGuildChat" ])]="<html>Invite people that use command (you can set it below) on guild chat.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoInviteGuildChatText" ])]="<html><tip_red>In use only if you have selected above option.</tip_red><br/>Select a phrase which will trigger you to invite a person after them writing on guild chat.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: ++;raid;invite.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoPassLead" ])]="<html><tip_blue>Who will be able to take leadership from you with a chosen whisper command?</tip_blue><br/>'custom' - allows you to set your own list of nicknames<br/>you want to allow take leadership from you.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoPassLeadText" ])]="<html>Select a phrase which will trigger you to pass leadership<br/>to a person after receiving a whisper.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: !;!!;lead.   </tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoPassLeadCustomList" ])]="<html><tip_red>In use only if you have 'Pass Lead' option set to 'custom'.</tip_red><br/>Your list of nicknames that you will pass leadership to,<br/>after wshipering you with a correct command<br/>you have set in the option above.<br/><tip_blue>List positions should be separated with semicolon (';'), for example:<br/>nickname1;nickname2;nickname3.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoLeave" ])]="<html>Leave group or raid after receiving whisper with correct command.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoLeaveText" ])]="<html>Select a phrase which will trigger you to leave<br/>group or raid after receiving a whisper.<br/><tip_blue>List positions should be separated with semicolon (';'), for example:<br/>-;--;leave.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoLeaveMapFilterList" ])]="<html><tip_red>In use only if you have set 'Leave from Whisper' option to either 'inclusion list' or 'exclusion list'.</tip_red><br/>Your list of maps that will be compared with your current location<br/>when someone triggers you to leave a group or raid by whispering a leave command.<br/>Exlusive means that if the map name is on the list you stay, if not then you leave.<br/>Inclusive is the other way. If map name is on the list you leave and if not then you stay.<br/><tip_blue>List positions should be separated with semicolon (';'), for example: The Empire;Irene;Kingdom of Elements.</tip_blue><br/><tip_blue>You can check map names with command: /aa map.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptReadyCheck" ])]="<html>Auto accept ready checks.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptMount" ])]="<html>Auto accept lightning bolt mount-up invite.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptQuest" ])]="<html>Auto accept shared quests.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "autoAcceptResurrection" ])]="<html>Auto accept resurrection offers.</html>"
--------------------
-- OTHER --
--------------------
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption1" ])]="<html><tip_blue>Automatically combines:<br/>amalgam, realgar, battlegrounds coins, and other items.</tip_blue><br/>It will only work when there has been a change in your bag<br/>and will go through all possible items.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption2" ])]="<html><tip_blue>Addon simplifies selling junk items with option to add any item of your choice.</tip_blue><br/>Sell item and addon will move next into same slot for you.<br/>Config additional items in NpcableStuff.lua</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption3" ])]="<html>Move equippable items<br/>(only items that are equal or weaker than equipped - addon checks item level)</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption8" ])]="<html>Move items that can be equipped and are tradeable</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption4" ])]="<html><tip_blue>Automatically skips skippable cutscenes</tip_blue><br/><tip_red>It breaks some quests, most notably in Dane!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption5" ])]="<html>Necromancer Supremacy helper.<br/><tip_blue>Highlights anyone from group who is within 6 m and puts text on screen.</tip_blue><br/><tip_red>Works only on Necromancer!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionBSS1" ])]="<html><tip_blue>Fast and easy search in bag and bank.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionBSS2" ])]="<html>Found items blink after pressing 'Enter'.<br/>You can set blink duration here.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption9" ])]="<html><tip_blue>Highlights quest related objects and units</tip_blue> - it does not highlight everything like ingame highlight does,<br/>which to myself was very annoying and this add-on is a result.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption10" ])]="<html>Selection - color over whole object, Ambient - color1 changing into color2<br/>and back into color1 within a set period.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption11" ])]="<html>Color 1</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption12" ])]="<html>Color 2<br/>(works only with AMBIENT mode)</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption13" ])]="<html>period during which Color 1 changes into Color 2<br/>(works only with AMBIENT mode)</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption14" ])]="<html>Should additional texts in teleport window be shown?<br/>For example 'Dane. Bee Ravine' will have added 'Fractal' raid name or any other text you have set.<br/>Check add-on page on alloder.pro for in-depth tutorial.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption15" ])]="<html><tip_blue>Automation of boring tasks that allow you to focus on battles in 3v3 and 6v6 formats.</tip_blue><br/><tip_red>Even if it's active here you have to right-click on the CA icon to activate the add-on itself.<br/>This option affects only visibility of CA button!</tip_red><br/>When activated add-on automatically accepts queue and leaves after the end of the battle.<br/>Allows automatic purchase of: Essence, Tools, Symbols of Glory and Gold.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOption16" ])]="<html>How much Combat Emblems should be kept?<br/>Only the value above set one will be spent for buying.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionMT1" ])]="<html>should background transparency be only active while moving,<br/>if set to off it will be active all the time and won't affect performance.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionMT2" ])]="<html>should map transparency be only active while moving,<br/>if set to off it will be active all the time and won't affect performance.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionMT3" ])]="<html>map transparency<br/>can be set from 0 to 1 with 0 being fully transparent and 1 being fully visible.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionMT4" ])]="<html>background transparency, can be set from 0 to 1 with 0 being fully transparent and 1 being fully visible.</html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionMT5" ])]="<html><tip_blue>Makes map transparent on movement or at all times.</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionMPP" ])]="<html><tip_blue>Allows to preview: mount, shell skins and pets<br/>by left clicking while holding alt on skin item linked to chat (same way as costumes can be previewed).</tip_blue><br/><tip_red>Note that some mount items don't contain any info about skin and can't be viewed in the addon.<br/>Developers take their time fixing it...</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionBtL1" ])]="<html><tip_blue>Speed up your resurrection!<br/>No more walking to the goblin!<br/>Just shout and throw mirra at him!</tip_blue></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionBtL2" ])]="<html>Instantly leave purgatory after accepting respawn.<br/><tip_red>Remember to keep a stockpile of mirra!</tip_red></html>"
locales["eng_eu"][FromWString(locales["eng_eu"][ "OtherOptionBtL3" ])]="<html>Instantly resurrect if you are out of combat when dying.<br/><tip_red>It will only work at the time of death.<br/>If combat ends later you have to accept yourself!</tip_red></html>"

-- to add new tooltip (development only)
--locales["eng_eu"][FromWString(locales["eng_eu"][ "localeName" ])]="<html><tip_red>tip_red</tip_red><br/><tip_blue>tip_blue</tip_blue><br/>long tip text|long tip text</html>"