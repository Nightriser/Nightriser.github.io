common.GetBitAnd = bit.band
common.GetBitOr = bit.bor
common.GetBitXor = bit.bxor