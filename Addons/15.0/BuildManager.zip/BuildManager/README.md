BuildManager
============

Allods Online addon for saving/loading builds.
Saves and restores skills and key bindings.

Latest version can be downloaded here:
https://alloder.pro/files/file/117-buildmanager/
