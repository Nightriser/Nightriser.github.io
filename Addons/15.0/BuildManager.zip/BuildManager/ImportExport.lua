-- Import and export to/from external formats

function ImportBuild( link )
	return ImportAlloderProLink( link ) or ImportWikiLink( link ) or ImportWikiLinkOld( link )
end

function ExportBuild( build, aClassName )
	return ExportAlloderProLink( build, aClassName ) or ExportWikiLink( build )
end

----------------------------------------------------------------------------------------------------
-- link format:
-- pts.allodswiki.ru/calc#!<class>!<talents>!<field1>!<field2>!<field3>
-- <class> - integer class id
-- <talents> - a letter for each skill (36 total), "." - not learned, otherwise skill level
-- <fieldN> - <left> "/" <RIGHT>
-- <left> - Make a 32-bit number from field talents row-wise from center (bit0) to upper left
--					corner (bit31). Store it in base-26 with lowercase letters as digits, little-endian.
-- <RIGHT> - Make a 32-bit number from field talents row-wise from center (bit0) to lower right
--					 corner (bit31). Store it in base-26 with uppercase letters as digits, little-endian.

local classIdTable = {
	DRUID	= "5",
	MAGE	= "2",
	NECROMANCER	= "4",
	PALADIN	= "7",
	PRIEST	= "3",
	PSIONIC	= "6",
	STALKER	= "8",
	WARRIOR	= "1",
	BARD	= "9",
	ENGINEER = "10",
	WARLOCK = "11"
}

function tonumber26( s )
	local n = 0
	for i = string.len( s ), 1, -1 do
		n = n * 26 + string.byte( s, i ) - string.byte( "a" )
	end
	return n
end

function tostring26( n )
	local s = ""
	while n > 0 do
		s = s .. string.char( string.byte( "a" ) + mod( n, 26 ) )
		n = math.floor( n / 26 )
	end
	return s
end

function indexToPos( index )
	local size = avatar.GetFieldTalentTableSize()
	local offset = math.floor( size.columnsCount * size.rowsCount / 2 )
	return { x = mod( index + offset, size.columnsCount ),
			 y = math.floor( (index + offset) / size.columnsCount ) }
end

function ImportWikiLink( link )
	local build = { talents = {}, fieldTalents = {}, binding = {} }

	local iter = string.gmatch( link, "!([^!]+)")
	iter() -- skip class id

	local talents = iter()
	if not talents then
		return nil
	end
	local size = avatar.GetBaseTalentTableSize()
	for i = 1, string.len( talents ) do
		local ch = string.sub( talents, i, i )
		if not string.find( ".123", ch ) then
			return nil
		end

		if ch ~= "." then
		local key = TalentKey( math.floor( (i - 1) / size.linesCount ), mod( i - 1, size.linesCount ) )
			build.talents[ key ] = tonumber( ch ) - 1
		end
	end

	local size = avatar.GetFieldTalentTableSize()
	for field = 0, size.fieldsCount - 1 do
		local str = iter()
		if not str then
			return nil
		end

		local _, _, left, right = string.find( str, "(%a*)/(%a*)" )
		left = tonumber26( left )
		right = tonumber26( string.lower( right ) )
		
		for i = 1, math.floor( size.columnsCount * size.rowsCount / 2 ) do
			if mod( left, 2 ) > 0 then
				local p = indexToPos( -i )
				build.fieldTalents[ FieldTalentKey( field, p.y, p.x ) ] = true
			end
			left = math.floor( left / 2 )
		end
		
		for i = -1, math.floor( size.columnsCount * size.rowsCount / 2 ) do
			if mod( right, 2 ) > 0 then
				local p = indexToPos( i )
				build.fieldTalents[ FieldTalentKey( field, p.y, p.x ) ] = true
				--common.LogInfo( common.GetAddonName(), 'field = '..field..';;p.y = '..p.y..';;p.x = '..p.x..';; i='..i..';; right = '..right)
			end
			right = math.floor( right / 2 )
		end

	end

	return build
end

local classMap = {
	DRUID	= "d",
	MAGE	= "m",
	NECROMANCER	= "n",
	PALADIN	= "t",
	PRIEST	= "p",
	PSIONIC	= "v",
	STALKER	= "s",
	WARRIOR	= "w",
	BARD	= "b",
	ENGINEER = "e",
	WARLOCK = "l"
}

local alphabet32 = {}
for i = 0, 31 do
	alphabet32[i] = i < 10 and tostring(i) or string.char( string.byte( "a" ) + (i - 10) )
end

local function intToBits(value, bits)
    -- returns a table of bits, most significant first.
    bits = bits or math.max(1, select(2, math.frexp(value)))
    local t = {} -- will contain the bits        
    for b = bits, 1, -1 do
        t[b] = math.fmod(value, 2)
        value = math.floor((value - t[b]) / 2)
    end
    return table.concat(t)
end

-- encodes bit string into base32 string
-- it does not checks string length, so caller should pass in correct amount of bits
local function bitStringToBase32(bitString)
	local encodedString = ''
	local bitsPerChunk = 5
	for from = 1, string.len(bitString), bitsPerChunk do
		local chunk = string.sub(bitString, from, from + bitsPerChunk - 1)
		local chunkValue = tonumber(chunk, 2)
		encodedString = encodedString .. alphabet32[chunkValue]
	end

	return encodedString
end

local function base32ToBitString(encodedString)
	local bitString = ''
	local bitsPerChunk = 5
	local len = string.len(encodedString)
	for from = 1, string.len(encodedString) do
		local chunk = string.sub(encodedString, from, from)
		local chunkValue = tonumber(chunk, 32)
		bitString = bitString .. intToBits(chunkValue, bitsPerChunk)
	end
	return bitString
end

local function GetClassTag(aClassName)
	for i, v in pairs( clTable ) do
		if aClassName == v then
			return classMap[i]
		end
	end
	return "error"
end

function ExportAlloderProLink( build, aClassName )
	local site = 'https://alloder.pro/calc'
	local link = site .. '#' .. GetClassTag(aClassName) .. "$"
	--avatar.GetClass()
	local bitString = ''
	local size = avatar.GetBaseTalentTableSize()
	for layer = 0, size.layersCount - 1 do
		for line = 0, size.linesCount - 1 do
			local rank = build.talents[ TalentKey( layer, line ) ]
			bitString = bitString .. (
					rank == 2 and '11' or
					rank == 1 and '10' or
					rank == 0 and '01' or
								  '00'
			)
		end
	end

	local size = avatar.GetFieldTalentTableSize()
	for field = 0, size.fieldsCount - 1 do
		for row = 0, size.rowsCount - 1 do
			for cell = 0, size.columnsCount - 1 do
				if row ~= (size.rowsCount - 1) / 2 or cell ~= (size.columnsCount - 1) / 2 then -- skip center cell
					bitString = bitString .. (build.fieldTalents[ FieldTalentKey( field, row, cell ) ] and "1" or "0")
				end
			end
		end

	end

	return link .. bitStringToBase32(bitString) .. '::13ydj3'
end

function ImportAlloderProLink( link )
	local build = { talents = {}, fieldTalents = {}, binding = {} }

	local class, encodedString = string.match( link, "#(%a)$([0-9a-z]+)")

	if not encodedString then
		return nil
	end

	local bitString = base32ToBitString(encodedString)
	local offset = 1

	local size = avatar.GetBaseTalentTableSize()
	for layer = 0, size.layersCount - 1 do
		for line = 0, size.linesCount - 1 do
			local rank = tonumber(string.sub(bitString, offset, offset+1), 2)
			build.talents[ TalentKey( layer, line ) ] = rank > 0 and (rank - 1) or nil
			offset = offset + 2
		end
	end

	local size = avatar.GetFieldTalentTableSize()
	for field = 0, size.fieldsCount - 1 do
		for row = 0, size.rowsCount - 1 do
			for cell = 0, size.columnsCount - 1 do
				if row ~= (size.rowsCount - 1) / 2 or cell ~= (size.columnsCount - 1) / 2 then -- skip center cell
					if string.sub(bitString, offset, offset) == '1' then
						build.fieldTalents[ FieldTalentKey( field, row, cell ) ] = true
					end
					offset = offset + 1
				end
			end
		end
	end

	return build
end

function ExportWikiLink( build )
	local link = "http://pts.allodswiki.ru/calc#!" .. classIdTable[ avatar.GetClass() ] .. "!"

	local size = avatar.GetBaseTalentTableSize()
	for layer = 0, size.layersCount - 1 do
		for line = 0, size.linesCount - 1 do
			local rank = build.talents[ TalentKey( layer, line ) ]
			if rank then
				link = link .. ( rank + 1 )
			else
				link = link .. "."
			end
		end
	end

	local size = avatar.GetFieldTalentTableSize()
	for field = 0, size.fieldsCount - 1 do
		local left = 0
		local right = 0
		for i = math.floor( size.columnsCount * size.rowsCount / 2 ), 2, -1 do
				local lp = indexToPos( -i )
				if build.fieldTalents[ FieldTalentKey( field, lp.y, lp.x ) ] then
					left = left + 1
				end
				left = left * 2
		end
		
		for i = math.floor( size.columnsCount * size.rowsCount / 2 ), 0, -1 do
				local rp = indexToPos( i )
				if build.fieldTalents[ FieldTalentKey( field, rp.y, rp.x ) ] then
					right = right + 1
				end
				right = right * 2
				--common.LogInfo( common.GetAddonName(), 'field = '..field..';;rp.y = '..rp.y..';;rp.x = '..rp.x..';; i='..i..';; right = '..right)
		end


		link = link .. "!" .. tostring26( left ) .. "/" .. string.upper( tostring26( right ) )
	end

	return link
end

----------------------------------------------------------------------------------------------------
-- Create a link to the build for the allodswiki.ru build calculator

function ExportWikiLinkOld( build )
	local classIdTable = {
		DRUID		= "_new#5",
		MAGE		= "_new#2",
		NECROMANCER	= "_new#4",
		PALADIN		= "#7",
		PRIEST		= "#3",
		PSIONIC		= "#6",
		STALKER		= "#8",
		WARRIOR		= "#1",
		BARD		= "#9"
	}

	local codes = "abcdefghijklmnopqrstuvwxyz" .. "ABCDEFGHIJKLMNOPQRSTUVWXYZ" .. "0123456789-"
	function Code( index )
		return string.sub( codes, index + 1, index + 1 )
	end

	local link = "http://www.allodswiki.ru/talents"
			.. classIdTable[ avatar.GetClass() ] .. "_"

	local size = avatar.GetBaseTalentTableSize()
	for layer = 0, size.layersCount - 1 do
		for line = 0, size.linesCount - 1 do
			local rank = build.talents[ TalentKey( layer, line ) ]
			if rank then
				link = link .. Code( layer * size.linesCount + line ) .. ( rank + 1 )
			end
		end
	end

	local size = avatar.GetFieldTalentTableSize()
	for field = 0, size.fieldsCount - 1 do
		link = link .. "_"

		for row = 0, size.rowsCount - 1 do
			for col = 0, size.columnsCount - 1 do
				if build.fieldTalents[ FieldTalentKey( field, row, col ) ] then
					link = link .. Code( row * size.columnsCount + col )
				end
			end
		end
	end

	return link .. "_1" -- 0: build is editable; 1: build is locked.
end

----------------------------------------------------------------------------------------------------

function mod( a, b )
	return a - math.floor(a/b) * b
end

-- Import build from a link to allodswiki.ru.
-- Only talents and field talents are filled.
function ImportWikiLinkOld( link )
	local build = {}
	build.talents = {}
	build.fieldTalents = {}
	build.binding = {}

	local codes = "abcdefghijklmnopqrstuvwxyz" .. "ABCDEFGHIJKLMNOPQRSTUVWXYZ" .. "0123456789-"
	function Number( code )
		local n = string.find( codes, code )
		return n and n - 1
	end

	local iter = string.gmatch( string.gsub( link, ".*#", "" ), "_[%a%d-]+")

	local size = avatar.GetBaseTalentTableSize()
	local talents = iter()
	if not talents then
		return nil
	end
	for i = 2, string.len( talents ), 2 do
		local skill = Number( string.sub( talents, i, i ) )
		local rank = tonumber( string.sub( talents, i + 1, i + 1 ) )
		if not skill or not rank or rank < 1 or rank > 3 then
			return nil
		end

		local key = TalentKey( math.floor( skill / size.linesCount ), mod( skill, size.linesCount ) )
		build.talents[ key ] = rank - 1
	end
	for i = 0, 2 do
		if not build.talents[ TalentKey( 0, i ) ] then
			return nil
		end
	end

	local size = avatar.GetFieldTalentTableSize()
	for field = 0, size.fieldsCount - 1 do
		local talents = iter()
		for i = 2, string.len( talents ) do
			local talent = Number( string.sub( talents, i, i ) )
			if not talent then
				return nil
			end

			local key = FieldTalentKey( field, math.floor(talent / size.columnsCount), mod( talent, size.columnsCount ) )
			build.fieldTalents[ key ] = true
		end
	end
	for i = 0, size.fieldsCount - 1 do
		local key = FieldTalentKey( i, math.floor( size.rowsCount / 2 ), math.floor( size.columnsCount / 2 ) )
		if not build.fieldTalents[ key ] then
			return nil
		end
	end

	return build
end

